import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import {isCorrectAnswer} from '../src/engine.js';import {createDictionaryLookup,sameWord} from '../src/dictionary.js';
const original=JSON.parse(fs.readFileSync(new URL('../src/vocabulary-data.json',import.meta.url))),supplement=JSON.parse(fs.readFileSync(new URL('../src/supplemental-vocabulary.json',import.meta.url))),base=original.units.flatMap(u=>u.words),words=supplement.words;
test('exact requested four supplements contain422 canonical entries with source proof',()=>{assert.equal(words.length,422);assert.deepEqual(supplement.counts,{primary:343,cardinals:30,ordinals:30,months:12,weekdays:7});assert.equal(supplement.groups.length,4);assert.equal(new Set([...base,...words].map(w=>w.id)).size,711);for(const w of words){assert.ok(w.english&&/[\u3400-\u9fff]/.test(w.chinese));assert.equal(w.sourcePdfPage,w.sourcePage+9);assert.ok(w.sourcePage>=119&&w.sourcePage<=127);assert.ok(w.textbookIpa.startsWith('/'));assert.ok(w.groupIds.length);assert.ok(!w.aliases.some(a=>(w.textbookInflections||[]).includes(a)&&a!==w.english));}assert.equal(supplement.sources[0].sha256,original.metadata.sourceFingerprint.sha256);});
test('photo pages 121–125 join the original textbook unit without copying entries or losing the Primary group',()=>{
 const primary=words.filter(w=>w.category==='primary'),added={};
 assert.equal(primary.length,343);
 for(const w of primary){
  assert.match(w.originalUnit,/^Starter Unit [123]$|^Unit [1-7]$/);
  const originalId=(w.originalUnit.startsWith('Starter ')?'starter':'unit')+w.originalUnit.split(' ').at(-1);
  const linked=w.sourcePage>=121&&w.sourcePage<=125;
  assert.deepEqual(w.groupIds,linked?['primary-school',originalId]:['primary-school']);
  assert.deepEqual(supplement.memberships[w.id],w.groupIds);
  if(linked){
   added[originalId]=(added[originalId]||0)+1;
   const canon=s=>s.normalize('NFKC').toLowerCase().replace(/[’]/g,"'");
   const unit=original.units.find(u=>u.id===originalId);
   assert.ok(unit);
   assert.ok(!unit.words.some(b=>[b.word,...(b.acceptedAnswers||[]),...(b.aliases||[])].map(canon).includes(canon(w.english))),w.english);
  }
 }
 assert.deepEqual(added,{starter3:37,unit1:50,unit2:48,unit3:29,unit4:24,unit5:21,unit6:15,unit7:22});
 for(const [group,n]of [['reference-numerals',60],['reference-months',12],['reference-weekdays',7]])assert.equal(words.filter(w=>w.groupIds.includes(group)).length,n);
});
test('case-sensitive lexical collisions preserve separate meanings and grading',async()=>{const all=[...base.map(w=>({english:w.word,chinese:w.meaning,caseSensitive:supplement.caseSensitiveIds.includes(w.id),status:'official-list'})),...words.map(w=>({...w,status:'official-list'}))];const lookup=createDictionaryLookup({textbook:all});for(const [lower,upper] of [['am','AM'],['us','US'],['it','IT'],['who','WHO'],['may','May']]){const a=all.find(w=>w.english===lower),b=all.find(w=>w.english===upper);assert.ok(a&&b);assert.notEqual(a.chinese,b.chinese);assert.equal(sameWord(a,b),false);assert.equal(isCorrectAnswer(a,upper),false);assert.equal(isCorrectAnswer(b,lower),false);assert.equal(isCorrectAnswer(a,lower),true);assert.equal((await lookup(lower)).chinese,a.chinese);assert.equal((await lookup(upper)).chinese,b.chinese);}});
test('variant spelling accepted while different spoken words and inflections remain distinct',()=>{const get=e=>words.find(w=>w.english===e);assert.equal(isCorrectAnswer({...get('colour'),answers:get('colour').aliases},'color'),true);assert.equal(isCorrectAnswer({...get('a'),answers:get('a').aliases},'an'),false);assert.equal(isCorrectAnswer({...get('child'),answers:get('child').aliases},'children'),false);assert.equal(isCorrectAnswer(get('o’clock'),"o'clock"),true);assert.equal(isCorrectAnswer(get('twenty'),'20'),false);});
