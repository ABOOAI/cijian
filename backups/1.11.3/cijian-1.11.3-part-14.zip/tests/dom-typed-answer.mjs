import * as phrasesModule from '../src/phrases.js';
import * as phrasesUIModule from '../src/phrases-ui.js';
import * as answerFocusModule from '../src/answer-focus.js';
import * as spellingDiffModule from '../src/spelling-diff.js';
import * as freshQuestionsModule from '../src/fresh-practice/generator.mjs';
import * as practiceNoveltyModule from '../src/practice-novelty.js';
import * as enterPracticeModule from '../src/enter-practice.js';
import * as queuePolicyModule from '../src/queue-policy.js';
import * as customSentencesModule from '../src/custom-sentences.js';
import * as localTranslationModule from '../src/local-translation.js';
import * as practiceTimerModule from '../src/practice-timer.js';
import * as practiceTimeUIModule from '../src/practice-time-ui.js';
import * as sentenceDictationModule from '../src/sentence-dictation.js';
import {JSDOM,VirtualConsole} from '/workspace/shared/vocabulary-qa/node_modules/jsdom/lib/api.js';
import {readFile,writeFile,mkdir} from 'node:fs/promises';import path from 'node:path';import {webcrypto} from 'node:crypto';import assert from 'node:assert/strict';
import * as reviewTimingModule from '../src/review-timing.js';
import * as correctionModule from '../src/correction.js';
import * as correctionUIModule from '../src/correction-ui.js';
import * as masteryModule from '../src/mastery.js';
import * as contextAudioModule from '../src/context-audio.js';
import * as adaptiveModule from '../src/adaptive.js';
import * as adaptiveUIModule from '../src/adaptive-ui.js';
import * as interactionModule from '../src/interactions.js';
import * as dictionaryModule from '../src/dictionary.js';
import * as audioModule from '../src/audio.js';
import * as scheduler from '../src/scheduler.js';import * as custom from '../src/custom-words.js';import {isCorrectAnswer} from '../src/engine.js';
const root=path.resolve(import.meta.dirname,'..'),key='word-garden.workspace.v2',results=[],errors=[];
globalThis.fetch=async url=>{const file=String(url).startsWith('file:')?new URL(url):path.join(root,'src',String(url).split('/').at(-1));return {ok:true,json:async()=>JSON.parse(await readFile(file,'utf8'))};};
const vocab=await import('../src/vocabulary.js');const html=await readFile(path.join(root,'index.html'),'utf8');const source=(await readFile(path.join(root,'src/app.js'),'utf8')).replace(/^import .*;\n/gm,'').replaceAll('import.meta.url',JSON.stringify(new URL('../src/app.js',import.meta.url).href));
const media=[];class AudioMock{constructor(src){this.src=src;this.paused=false;media.push(this)}async play(){}pause(){this.paused=true}}
const intervals=[];let dom,w;
async function boot(saved={},hash='#tasks'){
 dom?.window.close();const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));dom=new JSDOM(html,{url:'https://test.invalid/'+hash,runScripts:'outside-only',virtualConsole:vc,pretendToBeVisual:true});w=dom.window;
 Object.assign(w,{...phrasesModule,...phrasesUIModule,...answerFocusModule,...spellingDiffModule,...freshQuestionsModule,...practiceNoveltyModule,...enterPracticeModule,...queuePolicyModule,...customSentencesModule,...localTranslationModule,...practiceTimerModule,...practiceTimeUIModule,...sentenceDictationModule,...reviewTimingModule,...correctionModule,...correctionUIModule,...masteryModule,...contextAudioModule,...adaptiveModule,...adaptiveUIModule,...interactionModule,...dictionaryModule,...audioModule,...scheduler,...custom,isCorrectAnswer,BASE:vocab.WORDS,UNITS:vocab.UNITS,BOOK:vocab.BOOK,fetch:globalThis.fetch});w.Audio=AudioMock;w.crypto.randomUUID=()=>webcrypto.randomUUID();w.scrollTo=()=>{};intervals.length=0;w.setInterval=fn=>{intervals.push(fn);return intervals.length;};w.confirm=()=>true;w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;};w.speechSynthesis={getVoices:()=>[],cancel(){},speak(){}};w.SpeechSynthesisUtterance=function(t){this.text=t;};
 for(const[k,v]of Object.entries(saved))w.localStorage.setItem(k,v);
 await w.eval('(async()=>{'+source+'\n})()');
}
const storage=()=>Object.fromEntries(Array.from({length:w.localStorage.length},(_,i)=>{const k=w.localStorage.key(i);return[k,w.localStorage.getItem(k)]}));
const state=()=>JSON.parse(w.localStorage.getItem(key));const el=s=>{const e=w.document.querySelector(s);assert.ok(e,'missing '+s);return e;};
const click=s=>{const e=el(s);assert.ok(!e.disabled,'disabled '+s);e.click();};const val=(s,v)=>{const e=el(s);e.value=v;e.dispatchEvent(new w.Event('input',{bubbles:true}));e.dispatchEvent(new w.Event('change',{bubbles:true}));};
const text=()=>w.document.body.textContent;const check=(v,n)=>{assert.ok(v,n);results.push(n)};
const id='starter1-001',answer='unit';const enterMode=mode=>{click(`[data-view="${mode}"]`);click(`[data-practice="${id}"]`);if(mode==='dictation')media.at(-1).onended();};const submit=method=>method==='button'?click('#check-answer'):el('#spell-form').requestSubmit();
for(const mode of ['dictation','spelling'])for(const method of ['button','implicit'])for(const blank of ['', '   ']){await boot();enterMode(mode);val('#spell-input',blank);const prior=JSON.stringify(state().records);submit(method);submit(method);check(el('#spell-input').validationMessage.includes('请先输入答案'),'empty warning '+mode+'/'+method+'/'+blank.length);check(state().session.result===null&&JSON.stringify(state().records)===prior,'empty submits never grade '+mode+'/'+method+'/'+blank.length);val('#spell-input','uni');val('#spell-input',answer);check(el('#spell-input').checkValidity(),'editing clears stale validation '+mode+'/'+method+'/'+blank.length);submit(method);check(state().session.result.correct,'valid answer submits after empty '+mode+'/'+method+'/'+blank.length);check(!state().session.result.assisted&&state().records[id].skills[mode].successes===1,'no-hint first answer credited '+mode+'/'+method+'/'+blank.length);}
// Cross-mode exposure used to suppress this entirely independent attempt.
await boot({[key]:JSON.stringify({version:2,records:{},exposure:{[id]:Date.now()+600000},stars:0,session:null,results:{},settings:{steps:[1,5]}})});enterMode('dictation');w.document.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Control',code:'ControlLeft',ctrlKey:true}));w.document.dispatchEvent(new w.KeyboardEvent('keyup',{key:'Control',code:'ControlLeft',ctrlKey:false}));media.at(-1).onended();val('#spell-input',answer);click('#check-answer');check(!state().session.result.assisted&&state().records[id].skills.dictation.successes===1,'required audio and Ctrl replay are not hints');enterMode('spelling');val('#spell-input',answer);click('#check-answer');check(!state().session.result.assisted&&state().records[id].skills.spelling.successes===1,'same word previous mode cannot carry assistance');
await boot();enterMode('spelling');click('[data-action=hint]');val('#spell-input',answer);click('#check-answer');check(state().session.result.assistanceReason==='hint'&&state().records[id].skills.spelling.successes===0,'actual hint remains assisted');enterMode('dictation');val('#spell-input',answer);click('#check-answer');check(!state().session.result.assisted,'hint flag resets on a fresh mode attempt');
await boot();enterMode('spelling');val('#spell-input','wrong');click('#check-answer');click('#correction-submit');val('#correction-input',answer);click('#correction-submit');check(state().session.remediation.successes===1&&state().records[id].skills.spelling.successes===0,'immediate answer-copy correction never gains mastery');check(el('.correction-panel').textContent.includes('即时纠错'),'correction message identifies actual reason');enterMode('spelling');val('#spell-input',answer);click('#check-answer');check(!state().session.result.assisted&&state().session.result.ordinaryStrengthCredit&&el('.feedback').textContent.includes('原复习排期保留'),'new explicit ordinary attempt can credit without altering review due or claiming hints');
await boot();click('[data-view=spelling]');click('[data-action=module-start]');click('[data-action=hint]');val('#spell-input','unit');click('#check-answer');click('[data-action=next-item]');check(el('#spell-input').value===''&&el('#spell-input').validationMessage===''&&!state().session.hint,'next question resets draft validation and hint state');const next=vocab.WORDS.find(w=>w.id===state().session.items[state().session.index].wordId);el('#spell-input').dispatchEvent(new w.CompositionEvent('compositionstart',{bubbles:true}));val('#spell-input',next.english);el('#spell-input').dispatchEvent(new w.CompositionEvent('compositionend',{bubbles:true}));el('#spell-form').requestSubmit();check(state().session.result.correct&&!state().session.result.assisted,'IME/editing does not carry prior assistance');
await boot();click('[data-view=dictation]');click(`[data-practice="${id}"]`);val('#spell-input',answer);el('#spell-form').requestSubmit();check(state().session.result===null,'typed submit respects unfinished audio gate');media.at(-1).onended();el('#spell-form').requestSubmit();check(state().session.result.correct,'audio completion unlocks current bound input');
await boot({'word-garden.custom.v1':JSON.stringify({version:1,words:[{id:'custom-typed-check',english:'testling',chinese:'测试词',example:'This testling is useful.',group:'测试'}]})});click('[data-view=sentences]');val('#scope-select','custom');click('[data-context-word]');click('#check-answer');val('#spell-input','testling');el('#spell-form').requestSubmit();check(state().session.result.correct,'custom typed context also recovers from empty submission');check(errors.length===0,'no DOM runtime errors');console.log(JSON.stringify({passed:results.length,checks:results},null,2));await writeFile(path.join(root,'evidence/typed-answer-dom-report.json'),JSON.stringify({passed:results.length,checks:results},null,2));dom.window.close();
